# Single-track and smallest-angle FPP comparison

This study addresses Andrew Puckett's November 10, 2026 single-track question.
The published 26.264% useful-pT efficiency selected a leading-momentum,
truth-associated charged track, with no event-level multiplicity veto.

## Definitions

The new `candidates` ROOT tree retains one row per GEANT4 track ID crossing
both FPP1 and FPP2, before any cone, closest-approach, or angular cuts. Neutral
particles are excluded; charged primary and secondary particles are included.
Repeated crossings of one track retain the existing crossing-map behavior.
A candidate's chamber mask identifies whether it also crosses FPP3 and FPP4.
Multiplicity is a geometric proxy for reconstructibility, not measured
pattern-recognition multiplicity.

Three policies use the same transport sample and incident-proton denominator:

- `legacy`: preserve the original independent highest-momentum candidate
  choices for the four- and two-chamber topologies, solely as a reference.
- `single`: require exactly one front-pair candidate before any analysis cuts.
  That candidate must cross all four chambers below 12 degrees. This also
  vetoes extra front-pair tracks that miss the downstream pair.
- `min_angle`: choose the smallest polar angle among all front-pair tracks,
  with track ID as a deterministic tie breaker. Require that chosen track to
  cross all four chambers below 12 degrees. No outgoing momentum is used in
  the choice. A failing chosen track is not replaced by another candidate.

After choosing, apply the existing cone test, analyzer z-close interval,
s-close <= 1 cm, and the 0.07 <= pT <= 1.0 GeV/c window. The analyzer remains
55.88 cm, incident momentum 6.7 GeV/c, and physics list FTFP_BERT. Incoming
proton momentum, known from the upstream spectrometer in the intended
experiment, enters pT and Ay; it is distinct from the unmeasured outgoing
track momentum that was used in the legacy ranking.

The minimum-angle policy includes every accepted single-track event. It may
lose events relative to the legacy policy when its chosen track fails cuts or
lies below the useful-pT region. Per-event choices are saved for auditing.

## Interpretation limits

Angles and closest-approach quantities remain ideal truth-associated values,
as in the original FOM. The existing unsigned-drift wire fits are preserved
as closure diagnostics; these selections do not measure real multi-track
pattern recognition or chamber inefficiencies. The empirical GEp-III Ay
model is a single-track calibration. Applying it to recovered multi-track
events is an explicitly provisional FOM estimate, not a validation of that
sample's analyzing power or statistical independence.

## Reproduction and validation

Build in a separate directory to preserve the existing executable:

```sh
cmake -S . -B build-track-selection -DCMAKE_BUILD_TYPE=RelWithDebInfo \
  -DPython3_EXECUTABLE="$(command -v python3)"
cmake --build build-track-selection -j4
ctest --test-dir build-track-selection --output-on-failure
sbatch jobs/run_track_selection.slurm
```

The job reuses the original 100,000 incident-proton CSV and does not overwrite
old ROOT files. It records HEAD, the working diff, and input/binary hashes.
The analysis records source hashes, checks candidate uniqueness and source
event IDs, reconstructs the original selection from the candidate table,
compares all original physics branches against the old tree by entry, and
checks that the single-track useful sample is contained in the minimum-angle
sample. JSON and summary CSV files contain efficiencies, RMS effective Ay,
intrinsic and beam-polarization-weighted FOM, and Monte Carlo standard errors.
The audit CSV records one row per incident event including zero-track events.

The old 100,000-event ROOT file has event_id=-1, weight=1, incident_p_GeV=0
because it predates the input-metadata persistence correction already present
in HEAD. The analysis explicitly checks these defaults in every old entry
and excludes those three metadata fields from the physics-branch comparison.
The new run retains its actual CSV event IDs, weights, and 6.7 GeV/c momentum.
The old published FOM used the monoenergetic momentum override.

Use the ROOT-compatible Python selected by the farm environment (Python 3.9
for ROOT 6.30.04). CMake otherwise discovers Python 3.13, whose ROOT
bindings are unavailable. This was diagnosed by the integration check and
resolved through the explicit interpreter configuration above.
